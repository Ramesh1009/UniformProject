package com.sdettraining.runnerClass;

import org.testng.annotations.Test;

public class Day04 {
	
	@Test
	public void testMethod1(){
		System.out.println("testMethod1");
	}

}
