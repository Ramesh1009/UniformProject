package com.sdettraining.stepdefination;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class BaseTest {

	public WebDriver wd;


	public static WebDriver driver;
	public static Properties prop;


	public BaseTest() {
		prop = new Properties();
		try {
			FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"//Resource//browser-config.properties");
			prop.load(fs);
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	}
